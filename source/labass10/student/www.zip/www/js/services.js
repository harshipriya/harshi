angular.module('starter.services', [])
.service('mainservice', function($q, $http) {
   
})
.service('mainservice', function($q, $http) {
   
}) 
.service('RegisterService',function($q, $http){
    
})
;
